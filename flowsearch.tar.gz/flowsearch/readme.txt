1. application.properties 可修改运行的端口【server.port】
2. bin目录下的脚本启动组件，如：sh flow-search.sh
3. 页面访问需要开启组件在机器上的运行端口
4. 页面swagger：http://host:port/doc.html
5. 关闭程序 找到对应的进程杀死